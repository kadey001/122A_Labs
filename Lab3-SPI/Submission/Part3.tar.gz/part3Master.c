/*
 * Part3.c
 *
 * Created: 10/16/2019 5:05:53 PM
 * Author : Owner
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

